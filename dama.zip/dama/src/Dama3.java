/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 *//**
 *
 * @author Liz
 */
import java.awt.*;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.image.BufferedImage;
import java.awt.Insets;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JFrame;

public class Dama3 {

    static Metodhs mtd = new Metodhs();
    static JButton[][] button = new JButton[100][100];
    static Icon vazio = new ImageIcon("C:\\Users\\Lab. de Software\\Downloads\\dama\\src\\img\\b021a3c2f1cad21be6e3dcb665a363ac.jpg");
    static Icon Preto = new ImageIcon("C:\\Users\\Lab. de Software\\Downloads\\dama\\src\\img\\roxodef.png");
    static Icon white = new ImageIcon("C:\\Users\\Lab. de Software\\Downloads\\dama\\src\\img\\png-transparent-white-graphy-color-empty-banner-blue-angle-white.png");
    static Icon branco = new ImageIcon("C:\\Users\\Lab. de Software\\Downloads\\dama\\src\\img\\azul.png");
    static Icon verde = new ImageIcon("C:\\Users\\Lab. de Software\\Downloads\\dama\\src\\img\\tecido-patchwork-liso-verde-clarinho-bg088-necessaire.png");
    static GridBagConstraints gbc;
    private static final Insets insets = new Insets(0, 0, 0, 0);

    public static void main(final String args[]) {

        final JFrame frame = new JFrame("GridBagLayout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridBagLayout());

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                button[i][j] = new JButton(" ");
                addComponent(frame, button[i][j], i, j, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH);
            }
        }

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i % 2 == 1) && (j % 2 == 0)) {
                    button[i][j].setIcon(vazio);

                } else if ((i % 2 == 0) && (j % 2 == 1)) {
                    button[i][j].setIcon(vazio);

                } else {
                    button[i][j].setIcon(white);
                }

            }
        }

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 3; j++) {
                if ((i % 2 == 1) && (j % 2 == 0)) {

                    button[i][j].setIcon(Preto);
                } else if ((i % 2 == 0) && (j % 2 == 1)) {
                    button[i][j].setIcon(Preto);

                }

            }
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 5; j < 8; j++) {
                if ((i % 2 == 1) && (j % 2 == 0)) {
                    button[i][j].setIcon(branco);
                } else if ((i % 2 == 0) && (j % 2 == 1)) {
                    button[i][j].setIcon(branco);
                }

            }
        }

        //acoes dos botoes:
        button[1][0].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(1, 0);
                mtd.comer(1, 0);

            }
        });
        button[3][0].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(3, 0);
            }
        });
        button[5][0].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(5, 0);
            }
        });
        button[7][0].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(7, 0);
            }
        });
        button[0][1].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(0, 1);
            }
        });
        button[2][1].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(2, 1);
            }
        });
        button[4][1].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(4, 1);
            }
        });
        button[6][1].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(6, 1);
            }
        });

        button[1][2].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(1, 2);
            }
        });
        button[3][2].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(3, 2);
            }
        });
        button[5][2].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(5, 2);
            }
        });
        button[7][2].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(7, 2);
            }
        });
        button[0][3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(0, 3);
            }
        });
        button[2][3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(2, 3);
            }
        });

        button[4][3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Metodhs.changecolor(4, 3);
            }
        });
        button[6][3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(6, 3);
            }
        });
        button[1][4].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(1, 4);
            }
        });
        button[3][4].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(3, 4);
            }
        });
        button[5][4].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(5, 4);
            }
        });
        button[7][4].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(7, 4);
            }
        });
        button[0][5].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(0, 5);
            }
        });
        button[2][5].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(2, 5);
            }
        });
        button[4][5].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(4, 5);
            }
        });
        button[6][5].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(6, 5);
            }
        });
        button[1][6].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(1, 6);
            }
        });
        button[3][6].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(3, 6);
            }
        });
        button[5][6].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(5, 6);
            }
        });
        button[7][6].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(7, 6);
            }
        });
        button[0][7].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(0, 7);
            }
        });
        button[2][7].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(2, 7);
            }
        });
        button[4][7].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(4, 7);
            }
        });
          button[6][7].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mtd.changecolor(6, 7);
            }
        });
        //
        frame.setSize(1000, 1000);
        frame.setVisible(true);
    }

    private static void addComponent(Container container, Component component, int gridx, int gridy,
            int gridwidth, int gridheight, int anchor, int fill) {
        gbc = new GridBagConstraints(gridx, gridy, gridwidth, gridheight, 1, 1,
                anchor, fill, insets, 1, 1);
        container.add(component, gbc);
    }

}
