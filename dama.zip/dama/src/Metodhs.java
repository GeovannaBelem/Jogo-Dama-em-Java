/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.awt.Color;
import javax.swing.Icon;
import javax.swing.JButton;

/**
 *
 * @author Liz
 */
public class Metodhs extends Dama3 {

    static JButton botaoclick;
    static JButton outrobotao;
    static JButton outrobotao2;
    static JButton botaocomido;
    static int cont = 2;
    static boolean verdinha = false;
    static boolean comeu = false;


    static public void changecolor(int i, int j) {

        if ((button[i][j].getIcon() == Dama3.Preto) || (Dama3.button[i][j].getIcon() == Dama3.branco)) {
            /*Compara a imagem(icon) do botao clicado (passado por parametro) com as imagens (icons) das peça branca e preta*/
            int linha = 0;
            if (Dama3.button[i][j].getIcon() == Dama3.Preto) {
                linha = j + 1;
            } else if (Dama3.button[i][j].getIcon() == Dama3.branco) {
                linha = j - 1;
            }

            if (verdinha == false) {
                if (i == 0) {
                    botaoclick = Dama3.button[i][j];
                    if (button[i + 1][linha].getIcon() == vazio) {
                        button[i + 1][linha].setIcon(verde);
                        verdinha = true;
                        outrobotao = button[i + 1][linha];
                    }

                } else if (i == 7) {
                    botaoclick = Dama3.button[i][j];
                    if (button[i - 1][linha].getIcon() == vazio) {
                        button[i - 1][linha].setIcon(verde);
                        verdinha = true;
                        outrobotao = button[i + 1][linha];
                    }
                } else {

                    botaoclick = Dama3.button[i][j];
                    if (Dama3.button[i - 1][linha].getIcon() == Dama3.vazio) {
                        outrobotao = Dama3.button[i - 1][linha];
                        verdinha = true;
                        Dama3.button[i - 1][linha].setIcon(Dama3.verde);
                    }
                    if (Dama3.button[i + 1][linha].getIcon() == Dama3.vazio) {
                        outrobotao2 = Dama3.button[i + 1][linha];
                        verdinha = true;
                        Dama3.button[i + 1][linha].setIcon(Dama3.verde);
                    }

                }
            }

        } else if ((Dama3.button[i][j].getIcon() == Dama3.verde) && (comeu == false)) {
            verdinha = false;
            Dama3.button[i][j].setIcon(botaoclick.getIcon());
            botaoclick.setIcon(Dama3.vazio);
            btnvazio();
        } else if ((Dama3.button[i][j].getIcon() == Dama3.verde) && (comeu)) {

        }
    }

    static public void comer(int i, int j) {
        int cont = 0;
        int cont2 = 0;

    }

    static public void btnvazio() {
      
            if (outrobotao.getIcon() == Dama3.verde) {
                outrobotao.setIcon(Dama3.vazio);
            }
             if (outrobotao2.getIcon() == Dama3.verde) {
                outrobotao2.setIcon(Dama3.vazio);
            }
           
       
    }

}
