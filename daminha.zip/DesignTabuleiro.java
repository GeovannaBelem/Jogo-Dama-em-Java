/*
 * Equipe: Alana de Jesus, Geovanna Santos, João Marcelo Dias, Liz Oliveira,
 * Luana Barbosa, Maria Luiza de Araujo, Raissa Vieira e Thaynara Gonçalves. 
 */

public class DesignTabuleiro extends javax.swing.JFrame {

    Metodos metodo = new Metodos();

    public DesignTabuleiro() {
        initComponents();
        bb.setVisible(false);
        a.setVisible(false);
        c.setVisible(false);
        d.setVisible(false);
        e.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        c34 = new javax.swing.JButton();
        c14 = new javax.swing.JButton();
        c39 = new javax.swing.JButton();
        c5 = new javax.swing.JButton();
        c36 = new javax.swing.JButton();
        c4 = new javax.swing.JButton();
        c1 = new javax.swing.JButton();
        c42 = new javax.swing.JButton();
        c62 = new javax.swing.JButton();
        c11 = new javax.swing.JButton();
        c41 = new javax.swing.JButton();
        c61 = new javax.swing.JButton();
        c33 = new javax.swing.JButton();
        c31 = new javax.swing.JButton();
        c60 = new javax.swing.JButton();
        c49 = new javax.swing.JButton();
        c57 = new javax.swing.JButton();
        c10 = new javax.swing.JButton();
        c12 = new javax.swing.JButton();
        c19 = new javax.swing.JButton();
        c64 = new javax.swing.JButton();
        c6 = new javax.swing.JButton();
        c52 = new javax.swing.JButton();
        c59 = new javax.swing.JButton();
        c56 = new javax.swing.JButton();
        c35 = new javax.swing.JButton();
        c40 = new javax.swing.JButton();
        c21 = new javax.swing.JButton();
        c20 = new javax.swing.JButton();
        c51 = new javax.swing.JButton();
        c8 = new javax.swing.JButton();
        c55 = new javax.swing.JButton();
        c28 = new javax.swing.JButton();
        c17 = new javax.swing.JButton();
        c7 = new javax.swing.JButton();
        c26 = new javax.swing.JButton();
        c44 = new javax.swing.JButton();
        c38 = new javax.swing.JButton();
        c37 = new javax.swing.JButton();
        c32 = new javax.swing.JButton();
        c18 = new javax.swing.JButton();
        c30 = new javax.swing.JButton();
        c50 = new javax.swing.JButton();
        c27 = new javax.swing.JButton();
        c48 = new javax.swing.JButton();
        c58 = new javax.swing.JButton();
        c15 = new javax.swing.JButton();
        c54 = new javax.swing.JButton();
        c23 = new javax.swing.JButton();
        c29 = new javax.swing.JButton();
        c9 = new javax.swing.JButton();
        c3 = new javax.swing.JButton();
        c53 = new javax.swing.JButton();
        c45 = new javax.swing.JButton();
        c2 = new javax.swing.JButton();
        c63 = new javax.swing.JButton();
        c16 = new javax.swing.JButton();
        c13 = new javax.swing.JButton();
        c43 = new javax.swing.JButton();
        c47 = new javax.swing.JButton();
        c22 = new javax.swing.JButton();
        c24 = new javax.swing.JButton();
        c25 = new javax.swing.JButton();
        c46 = new javax.swing.JButton();
        bb = new javax.swing.JButton();
        a = new javax.swing.JButton();
        c = new javax.swing.JButton();
        d = new javax.swing.JButton();
        e = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Jogo Damas");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        c34.setBackground(new java.awt.Color(0, 0, 0));
        c34.setForeground(new java.awt.Color(242, 242, 242));
        c34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/b021a3c2f1cad21be6e3dcb665a363ac.jpg"))); // NOI18N
        c34.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c34.setBorderPainted(false);
        c34.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c34.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c34.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c34ActionPerformed(evt);
            }
        });

        c14.setBackground(new java.awt.Color(242, 242, 242));
        c14.setForeground(new java.awt.Color(242, 242, 242));
        c14.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c14.setBorderPainted(false);
        c14.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c14.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c14.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c39.setBackground(new java.awt.Color(242, 242, 242));
        c39.setForeground(new java.awt.Color(242, 242, 242));
        c39.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c39.setBorderPainted(false);
        c39.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c39.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c39.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c5.setBackground(new java.awt.Color(242, 242, 242));
        c5.setForeground(new java.awt.Color(242, 242, 242));
        c5.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c5.setBorderPainted(false);
        c5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c5.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c36.setBackground(new java.awt.Color(0, 0, 0));
        c36.setForeground(new java.awt.Color(242, 242, 242));
        c36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/b021a3c2f1cad21be6e3dcb665a363ac.jpg"))); // NOI18N
        c36.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c36.setBorderPainted(false);
        c36.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c36.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c36.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c36ActionPerformed(evt);
            }
        });

        c4.setBackground(new java.awt.Color(0, 0, 0));
        c4.setForeground(new java.awt.Color(242, 242, 242));
        c4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c4.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c4.setBorderPainted(false);
        c4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c4.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c4ActionPerformed(evt);
            }
        });

        c1.setBackground(new java.awt.Color(242, 242, 242));
        c1.setForeground(new java.awt.Color(242, 242, 242));
        c1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c1.setBorderPainted(false);
        c1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        c1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c42.setBackground(new java.awt.Color(242, 242, 242));
        c42.setForeground(new java.awt.Color(242, 242, 242));
        c42.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c42.setBorderPainted(false);
        c42.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c42.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c42.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c62.setBackground(new java.awt.Color(242, 242, 242));
        c62.setForeground(new java.awt.Color(242, 242, 242));
        c62.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c62.setBorderPainted(false);
        c62.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c62.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c62.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c11.setBackground(new java.awt.Color(0, 0, 0));
        c11.setForeground(new java.awt.Color(242, 242, 242));
        c11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c11.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c11.setBorderPainted(false);
        c11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c11.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c11.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c11ActionPerformed(evt);
            }
        });

        c41.setBackground(new java.awt.Color(0, 0, 0));
        c41.setForeground(new java.awt.Color(242, 242, 242));
        c41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c41.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c41.setBorderPainted(false);
        c41.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c41.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c41.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c41ActionPerformed(evt);
            }
        });

        c61.setBackground(new java.awt.Color(0, 0, 0));
        c61.setForeground(new java.awt.Color(242, 242, 242));
        c61.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c61.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c61.setBorderPainted(false);
        c61.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c61.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c61.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c61.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c61ActionPerformed(evt);
            }
        });

        c33.setBackground(new java.awt.Color(242, 242, 242));
        c33.setForeground(new java.awt.Color(242, 242, 242));
        c33.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c33.setBorderPainted(false);
        c33.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c33.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c33.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c33ActionPerformed(evt);
            }
        });

        c31.setBackground(new java.awt.Color(0, 0, 0));
        c31.setForeground(new java.awt.Color(242, 242, 242));
        c31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/b021a3c2f1cad21be6e3dcb665a363ac.jpg"))); // NOI18N
        c31.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c31.setBorderPainted(false);
        c31.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c31.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c31.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c31ActionPerformed(evt);
            }
        });

        c60.setBackground(new java.awt.Color(242, 242, 242));
        c60.setForeground(new java.awt.Color(242, 242, 242));
        c60.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c60.setBorderPainted(false);
        c60.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c60.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c60.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c49.setBackground(new java.awt.Color(242, 242, 242));
        c49.setForeground(new java.awt.Color(242, 242, 242));
        c49.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c49.setBorderPainted(false);
        c49.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c49.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c49.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c57.setBackground(new java.awt.Color(0, 0, 0));
        c57.setForeground(new java.awt.Color(242, 242, 242));
        c57.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c57.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c57.setBorderPainted(false);
        c57.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c57.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c57.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c57.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c57ActionPerformed(evt);
            }
        });

        c10.setBackground(new java.awt.Color(242, 242, 242));
        c10.setForeground(new java.awt.Color(242, 242, 242));
        c10.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c10.setBorderPainted(false);
        c10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c10.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c10.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c12.setBackground(new java.awt.Color(242, 242, 242));
        c12.setForeground(new java.awt.Color(242, 242, 242));
        c12.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c12.setBorderPainted(false);
        c12.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c12.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c12.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c19.setBackground(new java.awt.Color(242, 242, 242));
        c19.setForeground(new java.awt.Color(242, 242, 242));
        c19.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c19.setBorderPainted(false);
        c19.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c19.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c19.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c64.setBackground(new java.awt.Color(242, 242, 242));
        c64.setForeground(new java.awt.Color(242, 242, 242));
        c64.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c64.setBorderPainted(false);
        c64.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c64.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c64.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c6.setBackground(new java.awt.Color(0, 0, 0));
        c6.setForeground(new java.awt.Color(242, 242, 242));
        c6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c6.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c6.setBorderPainted(false);
        c6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c6.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c6.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c6ActionPerformed(evt);
            }
        });

        c52.setBackground(new java.awt.Color(0, 0, 0));
        c52.setForeground(new java.awt.Color(242, 242, 242));
        c52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c52.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c52.setBorderPainted(false);
        c52.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c52.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c52.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c52ActionPerformed(evt);
            }
        });

        c59.setBackground(new java.awt.Color(0, 0, 0));
        c59.setForeground(new java.awt.Color(242, 242, 242));
        c59.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c59.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c59.setBorderPainted(false);
        c59.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c59.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c59.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c59.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c59ActionPerformed(evt);
            }
        });

        c56.setBackground(new java.awt.Color(0, 0, 0));
        c56.setForeground(new java.awt.Color(242, 242, 242));
        c56.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c56.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c56.setBorderPainted(false);
        c56.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c56.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c56.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c56ActionPerformed(evt);
            }
        });

        c35.setBackground(new java.awt.Color(242, 242, 242));
        c35.setForeground(new java.awt.Color(242, 242, 242));
        c35.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c35.setBorderPainted(false);
        c35.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c35.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c35.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c40.setBackground(new java.awt.Color(0, 0, 0));
        c40.setForeground(new java.awt.Color(242, 242, 242));
        c40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/b021a3c2f1cad21be6e3dcb665a363ac.jpg"))); // NOI18N
        c40.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c40.setBorderPainted(false);
        c40.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c40.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c40.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c40ActionPerformed(evt);
            }
        });

        c21.setBackground(new java.awt.Color(242, 242, 242));
        c21.setForeground(new java.awt.Color(242, 242, 242));
        c21.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c21.setBorderPainted(false);
        c21.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c21.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c21.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c20.setBackground(new java.awt.Color(0, 0, 0));
        c20.setForeground(new java.awt.Color(242, 242, 242));
        c20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c20.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c20.setBorderPainted(false);
        c20.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c20.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c20.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c20ActionPerformed(evt);
            }
        });

        c51.setBackground(new java.awt.Color(242, 242, 242));
        c51.setForeground(new java.awt.Color(242, 242, 242));
        c51.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c51.setBorderPainted(false);
        c51.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c51.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c51.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c8.setBackground(new java.awt.Color(0, 0, 0));
        c8.setForeground(new java.awt.Color(242, 242, 242));
        c8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c8.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c8.setBorderPainted(false);
        c8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c8.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c8.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c8ActionPerformed(evt);
            }
        });

        c55.setBackground(new java.awt.Color(242, 242, 242));
        c55.setForeground(new java.awt.Color(242, 242, 242));
        c55.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c55.setBorderPainted(false);
        c55.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c55.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c55.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c28.setBackground(new java.awt.Color(242, 242, 242));
        c28.setForeground(new java.awt.Color(242, 242, 242));
        c28.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c28.setBorderPainted(false);
        c28.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c28.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c28.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c17.setBackground(new java.awt.Color(242, 242, 242));
        c17.setForeground(new java.awt.Color(242, 242, 242));
        c17.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c17.setBorderPainted(false);
        c17.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c17.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c17.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c7.setBackground(new java.awt.Color(242, 242, 242));
        c7.setForeground(new java.awt.Color(242, 242, 242));
        c7.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c7.setBorderPainted(false);
        c7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c7.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c7.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c26.setBackground(new java.awt.Color(242, 242, 242));
        c26.setForeground(new java.awt.Color(242, 242, 242));
        c26.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c26.setBorderPainted(false);
        c26.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c26.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c26.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c44.setBackground(new java.awt.Color(242, 242, 242));
        c44.setForeground(new java.awt.Color(242, 242, 242));
        c44.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c44.setBorderPainted(false);
        c44.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c44.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c44.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c38.setBackground(new java.awt.Color(0, 0, 0));
        c38.setForeground(new java.awt.Color(242, 242, 242));
        c38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/b021a3c2f1cad21be6e3dcb665a363ac.jpg"))); // NOI18N
        c38.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c38.setBorderPainted(false);
        c38.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c38.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c38.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c38ActionPerformed(evt);
            }
        });

        c37.setBackground(new java.awt.Color(242, 242, 242));
        c37.setForeground(new java.awt.Color(242, 242, 242));
        c37.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c37.setBorderPainted(false);
        c37.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c37.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c37.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c32.setBackground(new java.awt.Color(242, 242, 242));
        c32.setForeground(new java.awt.Color(242, 242, 242));
        c32.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c32.setBorderPainted(false);
        c32.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c32.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c32.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c18.setBackground(new java.awt.Color(0, 0, 0));
        c18.setForeground(new java.awt.Color(242, 242, 242));
        c18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c18.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c18.setBorderPainted(false);
        c18.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c18.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c18.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c18ActionPerformed(evt);
            }
        });

        c30.setBackground(new java.awt.Color(242, 242, 242));
        c30.setForeground(new java.awt.Color(242, 242, 242));
        c30.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c30.setBorderPainted(false);
        c30.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c30.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c30.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c50.setBackground(new java.awt.Color(0, 0, 0));
        c50.setForeground(new java.awt.Color(242, 242, 242));
        c50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c50.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c50.setBorderPainted(false);
        c50.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c50.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c50.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c50ActionPerformed(evt);
            }
        });

        c27.setBackground(new java.awt.Color(0, 0, 0));
        c27.setForeground(new java.awt.Color(242, 242, 242));
        c27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/b021a3c2f1cad21be6e3dcb665a363ac.jpg"))); // NOI18N
        c27.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c27.setBorderPainted(false);
        c27.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c27.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c27.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c27ActionPerformed(evt);
            }
        });

        c48.setBackground(new java.awt.Color(242, 242, 242));
        c48.setForeground(new java.awt.Color(242, 242, 242));
        c48.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c48.setBorderPainted(false);
        c48.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c48.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c48.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c58.setBackground(new java.awt.Color(242, 242, 242));
        c58.setForeground(new java.awt.Color(242, 242, 242));
        c58.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c58.setBorderPainted(false);
        c58.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c58.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c58.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c15.setBackground(new java.awt.Color(0, 0, 0));
        c15.setForeground(new java.awt.Color(242, 242, 242));
        c15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c15.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c15.setBorderPainted(false);
        c15.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c15.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c15.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c15ActionPerformed(evt);
            }
        });

        c54.setBackground(new java.awt.Color(0, 0, 0));
        c54.setForeground(new java.awt.Color(242, 242, 242));
        c54.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c54.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c54.setBorderPainted(false);
        c54.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c54.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c54.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c54ActionPerformed(evt);
            }
        });

        c23.setBackground(new java.awt.Color(242, 242, 242));
        c23.setForeground(new java.awt.Color(242, 242, 242));
        c23.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c23.setBorderPainted(false);
        c23.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c23.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c23.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c29.setBackground(new java.awt.Color(0, 0, 0));
        c29.setForeground(new java.awt.Color(242, 242, 242));
        c29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/b021a3c2f1cad21be6e3dcb665a363ac.jpg"))); // NOI18N
        c29.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c29.setBorderPainted(false);
        c29.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c29.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c29.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c29ActionPerformed(evt);
            }
        });

        c9.setBackground(new java.awt.Color(0, 0, 0));
        c9.setForeground(new java.awt.Color(242, 242, 242));
        c9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c9.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c9.setBorderPainted(false);
        c9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c9.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c9.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c9ActionPerformed(evt);
            }
        });

        c3.setBackground(new java.awt.Color(242, 242, 242));
        c3.setForeground(new java.awt.Color(242, 242, 242));
        c3.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c3.setBorderPainted(false);
        c3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c3.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c3.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c53.setBackground(new java.awt.Color(242, 242, 242));
        c53.setForeground(new java.awt.Color(242, 242, 242));
        c53.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c53.setBorderPainted(false);
        c53.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c53.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c53.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c45.setBackground(new java.awt.Color(0, 0, 0));
        c45.setForeground(new java.awt.Color(242, 242, 242));
        c45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c45.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c45.setBorderPainted(false);
        c45.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c45.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c45.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c45ActionPerformed(evt);
            }
        });

        c2.setBackground(new java.awt.Color(0, 0, 0));
        c2.setForeground(new java.awt.Color(242, 242, 242));
        c2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c2.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c2.setBorderPainted(false);
        c2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c2.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c2ActionPerformed(evt);
            }
        });

        c63.setBackground(new java.awt.Color(0, 0, 0));
        c63.setForeground(new java.awt.Color(242, 242, 242));
        c63.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c63.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c63.setBorderPainted(false);
        c63.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c63.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c63.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c63.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c63ActionPerformed(evt);
            }
        });

        c16.setBackground(new java.awt.Color(242, 242, 242));
        c16.setForeground(new java.awt.Color(242, 242, 242));
        c16.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c16.setBorderPainted(false);
        c16.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c16.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c16.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        c13.setBackground(new java.awt.Color(0, 0, 0));
        c13.setForeground(new java.awt.Color(242, 242, 242));
        c13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c13.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c13.setBorderPainted(false);
        c13.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c13.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c13.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c13ActionPerformed(evt);
            }
        });

        c43.setBackground(new java.awt.Color(0, 0, 0));
        c43.setForeground(new java.awt.Color(242, 242, 242));
        c43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c43.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c43.setBorderPainted(false);
        c43.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c43.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c43.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c43ActionPerformed(evt);
            }
        });

        c47.setBackground(new java.awt.Color(0, 0, 0));
        c47.setForeground(new java.awt.Color(242, 242, 242));
        c47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        c47.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c47.setBorderPainted(false);
        c47.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c47.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c47.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c47ActionPerformed(evt);
            }
        });

        c22.setBackground(new java.awt.Color(0, 0, 0));
        c22.setForeground(new java.awt.Color(242, 242, 242));
        c22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c22.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c22.setBorderPainted(false);
        c22.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c22.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c22.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c22ActionPerformed(evt);
            }
        });

        c24.setBackground(new java.awt.Color(0, 0, 0));
        c24.setForeground(new java.awt.Color(242, 242, 242));
        c24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        c24.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c24.setBorderPainted(false);
        c24.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c24.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c24.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c24ActionPerformed(evt);
            }
        });

        c25.setBackground(new java.awt.Color(0, 0, 0));
        c25.setForeground(new java.awt.Color(242, 242, 242));
        c25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/b021a3c2f1cad21be6e3dcb665a363ac.jpg"))); // NOI18N
        c25.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c25.setBorderPainted(false);
        c25.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c25.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c25.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c25ActionPerformed(evt);
            }
        });

        c46.setBackground(new java.awt.Color(242, 242, 242));
        c46.setForeground(new java.awt.Color(242, 242, 242));
        c46.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c46.setBorderPainted(false);
        c46.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c46.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c46.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(c49, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c50, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c51, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c52, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c53, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c54, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c55, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c56, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(c33, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c34, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c35, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c36, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c37, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c38, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c39, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c40, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(c41, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c42, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c43, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c44, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c45, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c46, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c47, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c48, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(c57, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c58, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c59, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c60, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c61, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c62, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c63, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c64, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(c17, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c18, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c19, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c20, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c21, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c22, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c23, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c24, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(c25, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c26, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c27, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c28, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c29, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c30, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c31, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c32, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(c9, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c10, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c11, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c12, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c13, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c14, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c15, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c16, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(c1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c6, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c7, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(c8, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c6, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c7, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c8, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c9, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c10, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c11, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c12, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c13, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c14, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c15, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c16, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c17, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c18, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c19, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c20, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c21, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c22, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c23, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c24, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c25, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c26, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c27, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c28, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c29, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c30, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c31, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c32, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c33, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c34, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c35, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c36, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c37, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c38, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c39, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c40, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c41, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c42, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c43, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c44, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c45, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c46, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c47, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c48, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c49, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c50, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c51, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c52, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c53, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c54, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c55, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c56, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c57, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c58, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c59, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c60, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c61, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c62, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c63, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(c64, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        bb.setBackground(new java.awt.Color(0, 0, 0));
        bb.setForeground(new java.awt.Color(242, 242, 242));
        bb.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/black-circle.png"))); // NOI18N
        bb.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        bb.setBorderPainted(false);
        bb.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bb.setMargin(new java.awt.Insets(0, 0, 0, 0));
        bb.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bbActionPerformed(evt);
            }
        });

        a.setBackground(new java.awt.Color(0, 0, 0));
        a.setForeground(new java.awt.Color(242, 242, 242));
        a.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/b021a3c2f1cad21be6e3dcb665a363ac.jpg"))); // NOI18N
        a.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        a.setBorderPainted(false);
        a.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        a.setMargin(new java.awt.Insets(0, 0, 0, 0));
        a.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        a.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aActionPerformed(evt);
            }
        });

        c.setBackground(new java.awt.Color(0, 0, 0));
        c.setForeground(new java.awt.Color(242, 242, 242));
        c.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tecido-patchwork-liso-verde-clarinho-bg088-necessaire.jpg"))); // NOI18N
        c.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        c.setBorderPainted(false);
        c.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        c.setMargin(new java.awt.Insets(0, 0, 0, 0));
        c.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        c.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cActionPerformed(evt);
            }
        });

        d.setBackground(new java.awt.Color(0, 0, 0));
        d.setForeground(new java.awt.Color(242, 242, 242));
        d.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/white-circle.png"))); // NOI18N
        d.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        d.setBorderPainted(false);
        d.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        d.setMargin(new java.awt.Insets(0, 0, 0, 0));
        d.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        e.setBackground(new java.awt.Color(0, 0, 0));
        e.setForeground(new java.awt.Color(242, 242, 242));
        e.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/b021a3c2f1cad21be6e3dcb665a363ac.jpg"))); // NOI18N
        e.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        e.setBorderPainted(false);
        e.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        e.setMargin(new java.awt.Insets(0, 0, 0, 0));
        e.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        e.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(c, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(a, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bb, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(d, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(e, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(c, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(a, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(bb, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(d, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(e, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void c18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c18ActionPerformed
        // TODO add your handling code here:
        if (c18.getIcon().toString().equals(bb.getIcon().toString())) { /*Aqui checa se a peca no botao eh preta ou branca, pois os movimentos sao diferentes para ambos e so podem se mover para frente*/
            metodo.changecolor(c18, c25, c27);
        } else {
            metodo.changecolor(c18, c9, c11);
        }

    }//GEN-LAST:event_c18ActionPerformed

    private void c27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c27ActionPerformed
        // TODO add your handling code here:
        if (c27.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c27, c34, c36);
        } else {
            metodo.changecolor(c27, c18, c20);
        }


    }//GEN-LAST:event_c27ActionPerformed

    private void c25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c25ActionPerformed
        // TODO add your handling code here:ç
        if (c25.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c25, c34);
        } else {
            metodo.changecolor(c25, c18);
        }
    }//GEN-LAST:event_c25ActionPerformed

    private void c20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c20ActionPerformed
        // TODO add your handling code here:
        if (c20.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c20, c27, c29);
        } else {
            metodo.changecolor(c20, c11, c13);
        }

    }//GEN-LAST:event_c20ActionPerformed

    private void c29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c29ActionPerformed
        // TODO add your handling code here:
        if (c29.getIcon().toString().equals(bb.getIcon().toString())) {

            metodo.changecolor(c29, c36, c38);
        } else {
            metodo.changecolor(c29, c20, c22);
        }
    }//GEN-LAST:event_c29ActionPerformed

    private void aActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_aActionPerformed

    private void cActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cActionPerformed

    private void bbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bbActionPerformed

    private void c22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c22ActionPerformed
        // TODO add your handling code here:
        if (c22.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c22, c29, c31);
        } else {
            metodo.changecolor(c22, c13, c15);
        }
    }//GEN-LAST:event_c22ActionPerformed

    private void c31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c31ActionPerformed
        // TODO add your handling code here:
        if (c31.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c31, c38, c40);
        } else {
            metodo.changecolor(c31, c22, c24);
        }

    }//GEN-LAST:event_c31ActionPerformed

    private void c2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c2ActionPerformed
        // TODO add your handling code here:
        metodo.changecolor(c2, c9, c11);

    }//GEN-LAST:event_c2ActionPerformed

    private void eActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_eActionPerformed

    private void c4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c4ActionPerformed
        // TODO add your handling code here:
        metodo.changecolor(c4, c11, c13);

    }//GEN-LAST:event_c4ActionPerformed

    private void c6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c6ActionPerformed
        // TODO add your handling code here:
        metodo.changecolor(c6, c13, c15);

    }//GEN-LAST:event_c6ActionPerformed

    private void c8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c8ActionPerformed
        // TODO add your handling code here:
        metodo.changecolor(c8, c15);

    }//GEN-LAST:event_c8ActionPerformed

    private void c9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c9ActionPerformed
        // TODO add your handling code here:
        if (c9.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c9, c18);
        } else {
            metodo.changecolor(c9, c2);
        }

    }//GEN-LAST:event_c9ActionPerformed

    private void c11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c11ActionPerformed
        // TODO add your handling code here:
        if (c11.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c11, c18, c20);
        } else {
            metodo.changecolor(c11, c2, c4);
        }
    }//GEN-LAST:event_c11ActionPerformed

    private void c13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c13ActionPerformed
        // TODO add your handling code here:
        if (c13.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c13, c20, c22);
        } else {
            metodo.changecolor(c13, c4, c6);
        }
    }//GEN-LAST:event_c13ActionPerformed

    private void c24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c24ActionPerformed
        // TODO add your handling code here:
        if (c24.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c24, c31);
        } else {
            metodo.changecolor(c24, c15);
        }

    }//GEN-LAST:event_c24ActionPerformed

    private void c15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c15ActionPerformed
        // TODO add your handling code here:
        if (c15.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c15, c24, c22);
        } else {
            metodo.changecolor(c15, c6, c8);
        }
    }//GEN-LAST:event_c15ActionPerformed

    private void c34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c34ActionPerformed
        // TODO add your handling code here:
        if (c34.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c34, c41, c43);
        } else {
            metodo.changecolor(c34, c25, c27);
        }
    }//GEN-LAST:event_c34ActionPerformed

    private void c36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c36ActionPerformed
        // TODO add your handling code here:
        if (c36.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c36, c43, c45);
        } else {
            metodo.changecolor(c36, c27, c29);
        }
    }//GEN-LAST:event_c36ActionPerformed

    private void c38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c38ActionPerformed
        // TODO add your handling code here:
        if (c38.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c38, c45, c47);
        } else {
            metodo.changecolor(c38, c29, c31);
        }
    }//GEN-LAST:event_c38ActionPerformed

    private void c45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c45ActionPerformed
        // TODO add your handling code here:
        if (c45.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c45, c52, c54);
        } else {
            metodo.changecolor(c45, c36, c38);
        }
    }//GEN-LAST:event_c45ActionPerformed

    private void c40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c40ActionPerformed
        // TODO add your handling code here:
        if (c40.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c40, c47);
        } else {
            metodo.changecolor(c40, c31);
        }
    }//GEN-LAST:event_c40ActionPerformed

    private void c41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c41ActionPerformed
        // TODO add your handling code here:
        if (c41.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c41, c50);
        } else {
            metodo.changecolor(c41, c34);
        }
    }//GEN-LAST:event_c41ActionPerformed

    private void c43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c43ActionPerformed
        // TODO add your handling code here:
        if (c43.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c43, c50, c52);
        } else {
            metodo.changecolor(c43, c34, c36);

        }
    }//GEN-LAST:event_c43ActionPerformed

    private void c47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c47ActionPerformed
        // TODO add your handling code here:
        if (c47.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c47, c54, c56);
        } else {
            metodo.changecolor(c47, c38, c40);
        }
    }//GEN-LAST:event_c47ActionPerformed

    private void c50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c50ActionPerformed
        // TODO add your handling code here:
        if (c50.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c50, c57, c59);
        } else {
            metodo.changecolor(c50, c41, c43);
        }
    }//GEN-LAST:event_c50ActionPerformed

    private void c33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c33ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_c33ActionPerformed

    private void c52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c52ActionPerformed
        // TODO add your handling code here:
        if (c52.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c52, c59, c61);
        } else {
            metodo.changecolor(c52, c43, c45);
        }

    }//GEN-LAST:event_c52ActionPerformed

    private void c54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c54ActionPerformed
        // TODO add your handling code here:
        if (c54.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c54, c61, c63);
        } else {
            metodo.changecolor(c54, c45, c47);

        }
    }//GEN-LAST:event_c54ActionPerformed

    private void c56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c56ActionPerformed
        // TODO add your handling code here:
        if (c54.getIcon().toString().equals(bb.getIcon().toString())) {
            metodo.changecolor(c56, c63);
        } else {
            metodo.changecolor(c56, c47);
        }
    }//GEN-LAST:event_c56ActionPerformed

    private void c57ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c57ActionPerformed
        // TODO add your handling code here:
        metodo.changecolor(c57, c50);
    }//GEN-LAST:event_c57ActionPerformed

    private void c59ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c59ActionPerformed
        // TODO add your handling code here:
        metodo.changecolor(c59, c50, c52);
    }//GEN-LAST:event_c59ActionPerformed

    private void c61ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c61ActionPerformed
        // TODO add your handling code here:
        metodo.changecolor(c61, c52, c54);
    }//GEN-LAST:event_c61ActionPerformed

    private void c63ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c63ActionPerformed
        // TODO add your handling code here:
        metodo.changecolor(c63, c54, c56);
    }//GEN-LAST:event_c63ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DesignTabuleiro().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton a;
    public static javax.swing.JButton bb;
    public static javax.swing.JButton c;
    private javax.swing.JButton c1;
    private javax.swing.JButton c10;
    private javax.swing.JButton c11;
    private javax.swing.JButton c12;
    private javax.swing.JButton c13;
    private javax.swing.JButton c14;
    private javax.swing.JButton c15;
    private javax.swing.JButton c16;
    private javax.swing.JButton c17;
    private javax.swing.JButton c18;
    private javax.swing.JButton c19;
    private javax.swing.JButton c2;
    private javax.swing.JButton c20;
    private javax.swing.JButton c21;
    private javax.swing.JButton c22;
    private javax.swing.JButton c23;
    private javax.swing.JButton c24;
    private javax.swing.JButton c25;
    private javax.swing.JButton c26;
    private javax.swing.JButton c27;
    private javax.swing.JButton c28;
    private javax.swing.JButton c29;
    private javax.swing.JButton c3;
    private javax.swing.JButton c30;
    private javax.swing.JButton c31;
    private javax.swing.JButton c32;
    private javax.swing.JButton c33;
    private javax.swing.JButton c34;
    private javax.swing.JButton c35;
    private javax.swing.JButton c36;
    private javax.swing.JButton c37;
    private javax.swing.JButton c38;
    private javax.swing.JButton c39;
    private javax.swing.JButton c4;
    private javax.swing.JButton c40;
    private javax.swing.JButton c41;
    private javax.swing.JButton c42;
    private javax.swing.JButton c43;
    private javax.swing.JButton c44;
    private javax.swing.JButton c45;
    private javax.swing.JButton c46;
    private javax.swing.JButton c47;
    private javax.swing.JButton c48;
    private javax.swing.JButton c49;
    private javax.swing.JButton c5;
    private javax.swing.JButton c50;
    private javax.swing.JButton c51;
    private javax.swing.JButton c52;
    private javax.swing.JButton c53;
    private javax.swing.JButton c54;
    private javax.swing.JButton c55;
    private javax.swing.JButton c56;
    private javax.swing.JButton c57;
    private javax.swing.JButton c58;
    private javax.swing.JButton c59;
    private javax.swing.JButton c6;
    private javax.swing.JButton c60;
    private javax.swing.JButton c61;
    private javax.swing.JButton c62;
    private javax.swing.JButton c63;
    private javax.swing.JButton c64;
    private javax.swing.JButton c7;
    private javax.swing.JButton c8;
    private javax.swing.JButton c9;
    public static javax.swing.JButton d;
    public static javax.swing.JButton e;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
