/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 * @author Liz
 */
public class Metodos {

    static JButton botaoclick;
    static JButton outrobotao;
    static JButton outrobotao2;
    boolean click = false;
    int vez = 0;

    public void changecolor(JButton btn1, JButton btn2, JButton btn3) {

        Metodos mtd = new Metodos();/* instancia a própria classe para poder ser usado um método dentro desse método*/
        String comparar = DesignTabuleiro.bb.getIcon().toString();  /*Pega a foto em um botão criado (peça preta) especificamente para isso e converte em string, apenas para compará-lo com o botao que vai ser clicado*/
        String comparar2 = DesignTabuleiro.a.getIcon().toString();  /*Pega a foto em um botão criado (cor preta) especificamente para isso e converte em string, apenas para compará-lo com a posição que o botao clicado pode ser movido*/
        Icon comparar3 = DesignTabuleiro.c.getIcon(); /*Pega a foto em um botão criado (cor verde) especificamente para isso e converte em string, apenas para atribuir a imagem a(s) posições que o botao clicado pode ser movido */
        String compararbranco = DesignTabuleiro.d.getIcon().toString();  /*Pega a foto em um botão criado (peça branca) especificamente para isso e converte em string, apenas para compará-lo com o botao que vai ser clicado*/
        if ((btn1.getIcon().toString().equals(comparar)) || (btn1.getIcon().toString().equals(compararbranco))) { /*Compara a imagem(icon) do botao clicado (passado por parametro) com as imagens (icons) das peça branca e preta*/
            botaoclick = btn1; /*guarda o botao clicado numa variavel*/
            click = true;
            if (btn2.getIcon().toString().equals(comparar2)) {   /*checa se a posição a qual o botao clicado pode se mover está vazia*/
                btn2.setIcon(comparar3); /*se tiver, dxa o botao verde para indicar que pode mover a peça para esse botao*/
                outrobotao = btn2; /*serve para mudar a cor para preto novamente qnd o usuário mover a peca*/
            }
            if (btn3.getIcon().toString().equals(comparar2)) {  /*faz a mesma coisa q o if anterior, porem com outra posicao que o jogador puder mover a peca*/
                btn3.setIcon(comparar3);
                outrobotao2 = btn3;
            }
        } else if (btn1.getIcon().toString().equals(comparar3.toString())) { /*caso o botao clicado nao conste uma peca e tiver verde, a funcao de mover a peca eh chamada*/
            mtd.mover(btn1);/*Chamando a funcao que move a peca*/
        }

    }

    public void changecolor(JButton btn1, JButton btn2) {
        /*Igual ao metodo anterior, porem apenas para pecas que so podem se mover para uma posicao*/
        Metodos mtd = new Metodos();
        Icon verdinho = new ImageIcon("C:\\Users\\Liz\\Documents\\NetBeansProjects\\dama\\src\\img\\tecido-patchwork-liso-verde-clarinho-bg088-necessaire.jpg");
        String compararbranco = DesignTabuleiro.d.getIcon().toString();
        String comparar = DesignTabuleiro.bb.getIcon().toString();
        String comparar2 = DesignTabuleiro.a.getIcon().toString();
        Icon comparar3 = DesignTabuleiro.c.getIcon();
        if ((btn1.getIcon().toString().equals(comparar)) || (btn1.getIcon().toString().equals(compararbranco))) {
            botaoclick = btn1;
            if (btn2.getIcon().toString().equals(comparar2)) {
                btn2.setIcon(comparar3);
                outrobotao = btn2;
            }

        } else if (btn1.getIcon().toString().equals(comparar3.toString())) {

            mtd.mover(btn1);
        }

    }

    public void mover(JButton btn1) {

        Icon comparar = DesignTabuleiro.bb.getIcon();
        Icon comparar2 = DesignTabuleiro.a.getIcon();
        Icon comparar3 = DesignTabuleiro.c.getIcon();
        Icon compararbranco = DesignTabuleiro.d.getIcon();
        if (btn1.getIcon().toString().equals(comparar3.toString())) { /*checa se o botao esta verde(indicativo que pode colocar a peca)*/
            if (botaoclick.getIcon().toString().equals(comparar.toString())) { /*checa se a peca q sera movita eh preta*/
                btn1.setIcon(comparar); /*Atribui a posicao desejada a imagem (icon) da peca preta*/
            } else {
                btn1.setIcon(compararbranco);/*Atribui a posicao desejada a imagem (icon) da peca branca*/
            }

            botaoclick.setIcon(comparar2); /*Como a peca ja foi movida, no botao que tava a peca é atribuido a imagem preta, para indicar que agr a casa ta vazia*/
        }

        if (outrobotao.getIcon().toString().equals(comparar3.toString())) /*Checa se o botao ta verde*/
        {
            outrobotao.setIcon(comparar2); /*Como tava verde, agora tem q a peca ja foi movida para a casa, a outra vira preta*/

        }
        if (outrobotao2.getIcon().toString().equals(comparar3.toString())) {
            outrobotao2.setIcon(comparar2);

        }

    }
}
